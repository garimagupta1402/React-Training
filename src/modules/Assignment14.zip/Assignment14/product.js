import React from "react";
import {
  makeStyles,
  Card,
  CardActionArea,
  CardContent,
  CardMedia,
  Button,
  Typography,
  CardActions,
} from "@material-ui/core";
import { Link } from "react-router-dom";


const styles=makeStyles();

const Product = (props) => {
  const classes = styles();
  return (
    <div>
      <Card className={classes.card} raised={true}>
        <CardActionArea>
          <CardMedia className={classes.media} image={props.image} />
          <CardContent>
            <Typography variant="h6">{props.title}</Typography>
            <Typography variant="p">{`Price : ${props.price}`}</Typography>
          </CardContent>
        </CardActionArea>
        <CardActions className={classes.action}>
          <Link to={`/product/${props.id}`} className={classes.link}>
            <Button variant="contained" className={classes.button}>
              {"Full Details"}
            </Button>
          </Link>
        </CardActions>
      </Card>
    </div>
  );
};
export default Product;
