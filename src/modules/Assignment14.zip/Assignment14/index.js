import { makeStyles } from "@material-ui/core";
import React from "react";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import PrivateRoute from "./route";
import Login from "./login";
import Home from "./home";
import Product from "./product";
import Description from "./description";

const Assignment14 = () => {
  const classes = useStyles();
  return (
    <div className={classes.mainContainer}>
      <BrowserRouter>
        <Switch>
          <Route exact path="/" component={Home} />
          <Route path="/login" component={Login} />
          <PrivateRoute exact path="/product" component={Product} />
          <PrivateRoute exact path="/product:id" component={Description} />
        </Switch>
      </BrowserRouter>
    </div>
  );
};
export default Assignment14;
