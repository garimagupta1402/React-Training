import React, { useEffect, useState } from "react";
import { makeStyles, Button, TextField, Paper } from "@material-ui/core";
import { useHistory } from "react-router-dom";
import validate from "./validate";

const styles = makeStyles({});

const user = { Username: "", Email: "", Password: "" };
export default function Login() {
  const classes = styles();
  const [user, setUser] = useState(user);
  const [isLogin, setIsLogin] = useState(false);
  const [isError, setIsError] = useState(user);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const history = useHistory();

  const handleSubmit = (event) => {
    event.preventDefault();
    setIsError(validate(user));
    setIsSubmitting(true);
    setIsLogin(true);
  };
  useEffect(() => {
    if (Object.keys(isError).length === 0 && isSubmitting) {
      setTimeout(() => {
        localStorage.setItem(
          "accessToken",
          "uigiueudiuebiuwehucrbhuibviubgbiugrir"
        );
        history.push("/product");
      }, 1000);
    }
  }, [isError]);
  const { Username, Email, Password } = user;
  const inputHandle = (event) => {
    const { name, value } = event.target;
    setUser({ ...user, [name]: value });
  };
  return (
    <div className={classes.container}>
      {
        <Paper className={classes.paper}>
          <form onSubmit={handleSubmit} className={classes.form}>
            <TextField
              id="input-with-icon-textfield"
              label="Username"
              required
              value={Username}
              name="Username"
              onChange={inputHandle}
              error={Boolean(isError.Username)}
              helperText={isError.Username}
            />
            <br />
            <TextField
              id="input-with-icon-textfield"
              label="Email ID"
              required
              value={Email}
              name="Email"
              onChange={inputHandle}
              error={Boolean(isError.Email)}
              helperText={isError.Email}
            />
            <br />
            <TextField
              id="input-with-icon-textfield"
              label="Password"
              required
              value={Password}
              name="Password"
              onChange={inputHandle}
              error={Boolean(isError.Password)}
              helperText={isError.Password}
            />
            <Button
              variant="contained"
              className={classes.button}
              type="submit"
            >
              {"Login"}
            </Button>
          </form>
        </Paper>
      }
    </div>
  );
}
