import { makeStyles } from "@material-ui/core";
import Footer from "./footer";
import React from "react";
import Navbar from "./nav";
import Product from "./product";
import data from "./data.json";

const styles = makeStyles({});

const Main = () => {
  const classes = styles();
  return (
    <div>
      <Navbar action={"Go Back"} isLogin={false} />
      <div className={classes.box}>
        {data.map((item) => {
          return (
            <Product
              key={item.id}
              id={item.id}
              image={item.image}
              des={item.description}
              price={item.price}
            />
          );
        })}
      </div>
      <Footer />
    </div>
  );
};
export default Main;
